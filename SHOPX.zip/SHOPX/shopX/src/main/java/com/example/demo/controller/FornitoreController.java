package com.example.demo.controller;

import java.text.SimpleDateFormat;





import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Fornitore;
import com.example.demo.model.InserimentoProdotto;
import com.example.demo.model.Prodotto;
import com.example.demo.model.Inserimento;
import com.example.demo.service.FornitoreService;
import com.example.demo.service.FornitoreServiceImpl;
import com.example.demo.service.ProdottoService;



@Controller
public class FornitoreController {
	
	
	@Autowired	
	private FornitoreService fornitoreService;
	

	
	FornitoreController(){
				
	}
	
	@RequestMapping("/")
	public String homePage(Model model) {
	
		return "home";
		
	}
	
	
	@GetMapping("/lista_fornitori")
	public String lista_fornitori(Model model) {
		
		model.addAttribute(
				
		"listFornitori", 
		
		fornitoreService.getAllFornitori());	
		
		return "lista_fornitori";
		
	}
	
	
	@RequestMapping("/getProdottiById/{id}")
	public String getProdottiById(Model model, @PathVariable("id") int id) {
				
		model.addAttribute(
				
		"listProdotti", 
		
		fornitoreService.getAllProdotti(id));	
		
		return "prodotti";	
		
	}

	
	@RequestMapping("/prodotto")
	public String setInsProdotto(Model model, @ModelAttribute(name="inserimento") InserimentoProdotto inserimento) {
		
		
		List<Fornitore> fornitori = fornitoreService.getAllFornitori();
		
		Fornitore fornitore =
		fornitoreService.getFornitoreByName(inserimento.getNomeFornitore());
		
		try {
		
			
		Prodotto prodotto = new Prodotto(
				fornitore,
				inserimento.getCategoria(),
				inserimento.getCodice(),
				inserimento.getDescrizione(),
				inserimento.getPrezzo(),
				inserimento.getPezzi());
				
		
		fornitoreService.addProdotto(fornitore, prodotto);
		
		
		model.addAttribute("listFornitori",
									fornitori);

		model.addAttribute("messaggio",
						"Inserimento Avvenuto!");
		
		return "inserimento_prodotto";
		
		
		
		} catch(Exception e) {


		model.addAttribute("listFornitori",
								fornitori);

		model.addAttribute("messaggio",
						"Erroe nell' Inserimento");
		
		return "inserimento_prodotto";
		
		}
	
											
		
	}
	
	@GetMapping("/get_prodotto")
	public String getInsProdotto(Model model, @ModelAttribute(name="inserimento") InserimentoProdotto inserimento) {
			
						
			model.addAttribute("listFornitori",
					fornitoreService.getAllFornitori());
					
			return "inserimento_prodotto";
	 											
	}

	
	@RequestMapping("/getFornitori/name")
	public String getFornitoriName(Model model, @ModelAttribute Fornitore fornitore) {
		
		if (fornitore.getNome()!=null) {
					
		model.addAttribute(
				
		"subListFornitori", 
				
		fornitoreService.getFornitoriByName(fornitore.getNome()));
		
		}
		
		return "cerca_fornitori";
		
		
		
	}
	
	@RequestMapping("/getFornitori/xname")
	public String getFornitoriByXName(Model model, @ModelAttribute Fornitore fornitore) {
		
		if (fornitore.getNome()!=null) {
					
		model.addAttribute(
				
		"subListFornitori", 
				
		fornitoreService.getFornitoriByXName(fornitore.getNome()));
		
		}
		
		return "cerca_fornitori";
		
		
		
	}

	
	@RequestMapping("/getProdotti/id")
	public String getProdottiID(Model model1, Model model2, @ModelAttribute Fornitore fornitore) {
		
		
		if (fornitore.getId()!=null) {					
			
			int ID = Integer.valueOf(fornitore.getId());
			
			Fornitore fornitoreX = fornitoreService.getFornitoreById(ID);
			
			if (fornitoreX != null) {
					
			model1.addAttribute(
				
						"listProdotti", 
		
						fornitoreService.getAllProdotti(ID));
		
			model2.addAttribute(
				
						"fornitore", 
				
						fornitoreService.getFornitoreById(ID));
			}
			
			else {
				
				
			}
		
		}
		
		return "prodotti";
				
		
	}
	
	@RequestMapping("/getProdotti/name")
	public String getProdottiName(Model model1, Model model2, @ModelAttribute Fornitore fornitore) {
		
		
		if (fornitore.getNome()!=null) {
			
			String name = fornitore.getNome();
			
			Fornitore fornitoreX = fornitoreService.getFornitoreByName(name);
			
			if (fornitoreX!=null) {
								
		
				model1.addAttribute(
				
						"listProdotti", 
		
						fornitoreService.getAllProdotti(name));
		
				model2.addAttribute(									
				
						"fornitore", 
						
						fornitoreX
				
						);
				
			}
			
		 }
					
		
		
		
		return "prodotti";
				
		
	}
	
	
	@RequestMapping("/fornitore")
	public String setFornitore(Model model, @ModelAttribute Fornitore fornitore) {
	
		if(!fornitore.getNome().equals("") && !fornitore.getDescrizione().equals("")){
				
			
				model.addAttribute("messaggio",
						"Fornitore salvato");
	
							    	 	   	   								
				fornitoreService.saveFornitore(fornitore);
			
				return "inserimento_fornitore";
						
	 	
		}
		
		else {
			model.addAttribute("messaggio",
					"Errore nell' Inserimento");
	
			return "inserimento_fornitore";
			
		}											
		
	}
	
	
	
}
