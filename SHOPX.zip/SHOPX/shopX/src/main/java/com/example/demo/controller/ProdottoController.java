package com.example.demo.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.model.Data;
import com.example.demo.model.InserimentoSconto;
import com.example.demo.model.Prodotto;
import com.example.demo.model.Sconto;
import com.example.demo.service.ProdottoService;


@Controller
public class ProdottoController {
	
	

	@Autowired	
	private ProdottoService prodottoService;

	
	ProdottoController(){
				
	}
	
	@RequestMapping("/getProdotti")
	public String homeProdotti(Model modelProdotto, 
		
		@ModelAttribute Prodotto prodotto) {
		
		if (prodotto!=null) {
		
		modelProdotto.addAttribute("listProdotti", 
				
				prodottoService.getAllProdotti());
		
		}
		
		return "tutti_prodotti";
		
	}
	
	
	@RequestMapping("/getProdotti/categoria")
	public String getProdottiCategoria(Model modelProdotto,  
			
		 @ModelAttribute Prodotto prodotto) {
		

		if (prodotto!=null) {
			
			String categoria = prodotto.getCategoria(); 
			
			modelProdotto.addAttribute(
					
					"listProdotti", 
							
					prodottoService.getAllProdotti(categoria));
			
		}
	
		return "tutti_prodotti";
		
		
	}	
	
	
	
	

	@RequestMapping("/sconto")
	public String setAddSconto(Model model, @ModelAttribute(name="inserimento") InserimentoSconto inserimento) {
		
		
		List<Prodotto> prodotti = prodottoService.getAllProdotti();
		
		Prodotto prodotto =
		prodottoService.getProdottoByCodice(inserimento.getCodiceProdotto());
				
		if (prodotti==null) model.addAttribute("errore",
				
				"Non ci sono Prodotti da selezionare");		
		
			
		try {
		
		Date scadenza = null;
		
		if (!inserimento.getTxtDate().equals(""))
						
			
		scadenza = Data.dateFormat(inserimento.getTxtDate());
				
				
		//if (inserimento.getPrezzoSconto()!=0 && inserimento.getPrezzoSconto()!=null) {
					
			
		Sconto sconto = new Sconto(prodotto, 
								   scadenza,
								   inserimento.getPrezzoSconto(),
								   inserimento.getMinimoPrezzoSconto(),
								   inserimento.getMinimoPezziSconto());
		
		List<Sconto> sconti = prodotto.getSconti();

		sconti.add(sconto);

		prodotto.setSconti(sconti);
		
		prodottoService.addScontiProdotto(prodotto, sconti);
	
		model.addAttribute("errore", "Inserimento Avvenuto!");
		
		model.addAttribute("listProdotti", prodotti);

		return "inserimento_sconto";
				
		
		} catch(Exception e) {

		model.addAttribute("listProdotti", prodotti);
		

		model.addAttribute("errore", "Errore nell'inserimento");

		return "inserimento_sconto";
		
		}
	
		
		
											
		
	}
	
	@GetMapping("/get_sconto")
	public String getAddSconto(Model model, @ModelAttribute("inserimento") InserimentoSconto inserimento) {
		
		//inserimento.setScadenzaSconto(new Date())

		model.addAttribute("listProdotti",
					prodottoService.getAllProdotti());
			
		return "aggiornamento_sconto";
	 											
	}

}
