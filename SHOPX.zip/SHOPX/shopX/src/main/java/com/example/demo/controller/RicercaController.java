package com.example.demo.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.demo.model.Prodotto;
import com.example.demo.model.ScontoRicercato;
import com.example.demo.service.QueryServiceProdotto;

import org.springframework.web.bind.annotation.ModelAttribute;
import com.example.demo.model.Ricerca;
import com.example.demo.model.Sconto;


import java.util.Date;
import java.util.ArrayList;
import com.example.demo.model.Data;

@Controller
public class RicercaController {
	

	@Autowired
	private QueryServiceProdotto queryProdotto;
	
	
	@RequestMapping("/ricerca")
	public String ricerca(Model model, @ModelAttribute("ricerca") Ricerca ricerca) {
		
		if (ricerca.getPezzi()==null ||
				ricerca.getScadenzaTXT()==null) {
			if (ricerca.getPezzi()==null) ricerca.setPezzi(0);
			if (ricerca.getScadenzaTXT()==null) 
			ricerca.setScadenzaTXT(Data.txtDataNow());
		} else {
			
			
	    	
		String descrizione = ricerca.getDescrizione();
		int pezzi = ricerca.getPezzi();
		Date scadenza = Data.dateFormat(ricerca.getScadenzaTXT());
		
	
		List<Prodotto> prodotti = queryProdotto.getProdotti(descrizione,pezzi);
		
		List<Sconto> sconti1 = new ArrayList<>();
		List<ScontoRicercato> scontiRicercati = new ArrayList<>();
 

		for(Prodotto p : prodotti) {
			
			List<Sconto> sconti = p.getSconti();
			
			float min = 100000000;
			
			if (sconti!=null) {
				for(Sconto sconto : sconti) {
				if(sconto != null) { 
				
				Date scadenza2 = sconto.getScadenzaSconto();				
				
				if (scadenza2!=null)
				if (scadenza2.before(scadenza)) {
					sconti1.add(sconto);
					float prezzo = p.getPrezzo();					
					float totale2 = prezzo*pezzi;
				if (totale2>=sconto.getMinimoPrezzoSconto() &&
					pezzi>=sconto.getMinimoPezziSconto()) {
					//float scontoPercent = sconto.getPercentualeSconto();
					//float totaleSconto = totale2 - (float)totale2*scontoPercent/(float)100;				
					ScontoRicercato scontoRicercato = new ScontoRicercato(sconto, totale2);
					//scontoRicercato.calcolaScontoTotale();
					
					float tot1 = scontoRicercato.getTotaleSconto();
					
					if(tot1<=min) ScontoRicercato.setScontoMigliore(scontoRicercato);
					
					scontiRicercati.add(scontoRicercato);					
					
					
				}
				}
				}
			}}
		}
		
	
		
		model.addAttribute("listSconti1", sconti1);
		model.addAttribute("listSconti2", scontiRicercati);
		model.addAttribute("pezzi",pezzi);
		
		if (ScontoRicercato.getScontoMigliore()!=null)
		model.addAttribute("scontoMigliore",ScontoRicercato.getScontoMigliore());

	
		System.out.print(scadenza);

				
		}
		
		return "ricerca";
	}	
}



