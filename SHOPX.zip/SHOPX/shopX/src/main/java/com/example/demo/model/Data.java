package com.example.demo.model;

import java.text.DateFormat;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public class Data {
	
	public static String txtDataNow() {
		
		int d = LocalDate.now().getDayOfMonth();
		int m = LocalDate.now().getMonthValue();
		int y = LocalDate.now().getYear();
		
		return d+"/"+m+"/"+y;
	}
		
	public static Date dateFormat(String data) {
		
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT, Locale.ITALY);
			
		df.setLenient(false);
		
		try {
		Date dataFrm = df.parse(data);
		//String txtDate = df.format(dataFrm);
		
		
		//System.out.println("TXTdate="+txtDate);
				
		return dataFrm;
		
		} catch(ParseException e) {
			
			return null;
		}
	}
	
	
}
