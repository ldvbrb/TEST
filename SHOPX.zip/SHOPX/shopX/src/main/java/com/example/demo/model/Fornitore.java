package com.example.demo.model;

import java.util.List;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

import org.hibernate.annotations.Columns;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;



@Entity
@Table(name = "fornitori")
public class Fornitore {
		
	@Id
	@Column(name = "id")
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Integer id;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "nome", unique=true)
	private String nome;
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	@Column(name = "descrizione")
	private String descrizione;
	
	/*
	@OneToOne(mappedBy="fornitore", cascade = CascadeType.ALL)
	private Categoria categoria;
			
	
	public Categoria getCategoria() {
		return categoria;
	}

	public void setCategoria(Categoria categoria) {
		this.categoria = categoria;
	}
	*/

	//fetch = FetchType.EAGER, 
	@OneToMany(mappedBy="fornitore", cascade = CascadeType.ALL)
	private List<Prodotto> prodotti;

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	
	@OneToMany(targetEntity=Prodotto.class, mappedBy="fornitore", cascade = CascadeType.ALL)	
	public List<Prodotto> getProdotti() {
		return prodotti;
	}

	public void setProdotti(List<Prodotto> prodotti) {
		this.prodotti = prodotti;
	}
	
	
	public Fornitore(String nome, String descrizione) {
		
		this.nome = nome;
		this.descrizione = descrizione;		
		
	}
	
	public Fornitore() {					
		
	}
	
	public Fornitore(String nome, String descrizione, List<Prodotto> prodotti) {
				
		this.nome = nome;
		this.descrizione = descrizione;
		this.prodotti = prodotti;

		
	}

}
