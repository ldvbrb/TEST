package com.example.demo.model;

import java.util.Date;

public class InserimentoProdotto extends Prodotto{		
	
	private String nomeFornitore;
	
	private String descrizioneFornitore;
	
		
	public String getNomeFornitore() {
		return nomeFornitore;
	}

	public void setNomeFornitore(String nomeFornitore) {
		this.nomeFornitore = nomeFornitore;
	}

	public String getDescrizioneFornitore() {
		return descrizioneFornitore;
	}

	public void setDescrizioneFornitore(String descrizioneFornitore) {
		this.descrizioneFornitore = descrizioneFornitore;
	}
		
			
	InserimentoProdotto(){
		
	}

	public InserimentoProdotto(String nomeFornitore, String descrizioneFornitore) {
		super();
		this.nomeFornitore = nomeFornitore;
		this.descrizioneFornitore = descrizioneFornitore;
	}


}
