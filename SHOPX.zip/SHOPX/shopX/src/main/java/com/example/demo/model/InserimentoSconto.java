package com.example.demo.model;

import java.util.Date;

public class InserimentoSconto extends Sconto{
	
	String codiceProdotto;
	
	String txtDate;
   
	public String getCodiceProdotto() {
		return codiceProdotto;
	}


	public void setCodiceProdotto(String codiceProdotto) {
		this.codiceProdotto = codiceProdotto;
	}
	

	public String getTxtDate() {
		return txtDate;
	}


	public void setTxtDate(String txtDate) {
		this.txtDate = txtDate;
	}


	InserimentoSconto(){
		
	}
	



}
