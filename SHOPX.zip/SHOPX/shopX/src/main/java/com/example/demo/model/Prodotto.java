package com.example.demo.model;

import java.text.ParseException;



import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "prodotti")
public class Prodotto {
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Integer id;
	
	//@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column(name = "codice", unique=true)
	private String codice;
	
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "descrizione", unique=true)
	private String descrizione;
	
	@Column(name = "categoria")
	private String categoria;
	
	@Column(name = "pezzi")
	private Integer pezzi;
			
	public Integer getPezzi() {
		return pezzi;
	}


	public void setPezzi(Integer pezzi) {
		this.pezzi = pezzi;
	}


	public String getCategoria() {
		return categoria;
	}


	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}

	@Temporal(TemporalType.DATE)
	//@DateTimeFormat(pattern = "DD-MM-YYYY")
	@Column(name = "datacreazione")
	private Date datacreazione;
	
	@Column
	private Float prezzo;
			
	@OneToMany(mappedBy="prodotto", cascade = CascadeType.ALL)
	private List<Sconto> sconti;
	
	@ManyToOne
	@JoinColumn(name = "fornitore_id", referencedColumnName = "id",  nullable=false, unique=true)
	private Fornitore fornitore;
	
	@OneToMany(targetEntity = Sconto.class, mappedBy="prodotto", cascade = CascadeType.ALL)
	public List<Sconto> getSconti() {
		return sconti;
	}


	public void setSconti(List<Sconto> sconti) {
		this.sconti = sconti;
	}

	@ManyToOne//(fetch = FetchType.LAZY)
	public Fornitore getFornitore() {
		return fornitore;
	}


	public void setFornitore(Fornitore fornitore) {
		this.fornitore = fornitore;
	}


	public Float getPrezzo() {
		return prezzo;
	}


	public void setPrezzo(Float prezzo) {
		this.prezzo = prezzo;
	}


	public String getCodice() {
		return codice;
	}


	public void setCodice(String codice) {
		this.codice = codice;
	}


	public String getDescrizione() {
		return descrizione;
	}


	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}


	public Date getDatacreazione() {
		return datacreazione;
	}


	public void setDatacreazione(Date datacreazione) {
		this.datacreazione = datacreazione;
	}


	public Prodotto() {
		
	}
	
	public Date getDataNow() {
		Calendar calendario = Calendar.getInstance();		
		//Date data;
		return calendario.getTime();
	}
	
	public Prodotto(Fornitore fornitore, String categoria, String codice, String descrizione, float prezzo, int pezzi) {
		
		this.fornitore = fornitore;
		this.categoria = categoria;
		this.codice = codice;
		this.descrizione = descrizione;
		this.prezzo = prezzo;	
		this.pezzi = pezzi;
		//Date data = new Date();
		//System.out.println("oggi:"+getDataNow());
		this.datacreazione = getDataNow();
	}


	
	
}
