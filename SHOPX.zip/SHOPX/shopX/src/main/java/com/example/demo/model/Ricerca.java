package com.example.demo.model;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import java.text.SimpleDateFormat;

public class Ricerca {
	
	String descrizione;
	Integer pezzi;
	
	//@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern="yyyy-mm-dd")	 
	Date scadenzaSconto;
		
	private String scadenzaTXT;
	
	public void setScadenzaTXT(String data) {		
		this.scadenzaTXT = data;
	}
	
	public String getScadenzaTXT() {
		return scadenzaTXT;
	}
	
	public Date getScadenzaSconto() {
		return scadenzaSconto;
	}
	public void setScadenzaSconto(Date scadenzaSconto) {
		this.scadenzaSconto = scadenzaSconto;
	}
	public String getDescrizione() {
		return descrizione;
	}
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}
	public Integer getPezzi() {
		return pezzi;
	}
	public void setPezzi(Integer pezzi) {
		this.pezzi = pezzi;
	}

	
	

}
