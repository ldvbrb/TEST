package com.example.demo.model;

import java.util.Date;


import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "sconti")
public class Sconto {
	
	@Column
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Integer idSconto;
	 
	@Temporal(TemporalType.DATE)
	@DateTimeFormat (pattern="yyyy-mm-dd")
	@Column
	private Date scadenzaSconto;
	
	@Column
	private Float percentualeSconto;
	
	@Column
	private Float prezzoSconto;
	
	@Column
	private Float minimoPrezzoSconto;
	
	@Column
	private Integer minimoPezziSconto;
			

	
	public Integer getIdSconto() {
		return idSconto;
	}


	public void setIdSconto(Integer idSconto) {
		this.idSconto = idSconto;
	}

	public Date getScadenzaSconto() {
		return scadenzaSconto;
	}

	public void setScadenzaSconto(Date scadenzaSconto) {
		this.scadenzaSconto = scadenzaSconto;
	}

	public Float getPercentualeSconto() {
		return percentualeSconto;
	}

	public void setPercentualeSconto(Float percentualeSconto) {
		this.percentualeSconto = percentualeSconto;
	}

	public Float getPrezzoSconto() {
		return prezzoSconto;
	}

	public void setPrezzoSconto(Float prezzoSconto) {
		this.prezzoSconto = prezzoSconto;
	}

	public Float getMinimoPrezzoSconto() {
		return minimoPrezzoSconto;
	}

	public void setMinimoPrezzoSconto(Float minimoPrezzoSconto) {
		this.minimoPrezzoSconto = minimoPrezzoSconto;
	}

	public Integer getMinimoPezziSconto() {
		return minimoPezziSconto;
	}

	public void setMinimoPezziSconto(Integer minimoPezziSconto) {
		this.minimoPezziSconto = minimoPezziSconto;
	}
	@ManyToOne
	public Prodotto getProdotto() {
		return prodotto;
	}

	public void setProdotto(Prodotto prodotto) {
		this.prodotto = prodotto;
	}

	@ManyToOne
	@JoinColumn(name = "idProdotto", referencedColumnName = "id", updatable = true, insertable = true)
	private Prodotto prodotto;
	
	public Sconto(){
		
	}
	
	public Sconto(Prodotto prodotto, Date scadenzaSconto, Float prezzoSconto, Float minimoPrezzoSconto, Integer minimoPezziSconto) {		
		this.scadenzaSconto = scadenzaSconto;
		this.prezzoSconto = prezzoSconto;
		this.minimoPrezzoSconto = minimoPrezzoSconto;
		this.minimoPezziSconto = minimoPezziSconto;
		this.prodotto = prodotto;
		this.percentualeSconto = getPercentuale(prodotto.getPrezzo(), prezzoSconto);
	}

	public Sconto(Prodotto prodotto, float prezzoSconto){
		
		this.prodotto = prodotto;
		
		this.prezzoSconto = prezzoSconto;
		
	}
	
	public Float getPercentuale(float prezzo, float prezzoSconto) {
		//prezzo : prezzoSconto = 100 : x;
		return 100 - prezzoSconto * 100/prezzo;
		
	}

}
