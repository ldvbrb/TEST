package com.example.demo.model;

public class ScontoRicercato extends Sconto {
		
	float totale;
	float totaleSconto;
	private static ScontoRicercato scontoMigliore;
	
	public static ScontoRicercato getScontoMigliore() {

		return scontoMigliore;
	}
	
	public static void setScontoMigliore(ScontoRicercato scontoMigliore) {
		ScontoRicercato.scontoMigliore = scontoMigliore;
	}

	public float getTotaleSconto() {	
		return totale - (float)totale*getPercentualeSconto()/(float)100;		
	}
	
	void setScontoTotale(){
		this.totaleSconto = getTotaleSconto();
	}
	

	public ScontoRicercato(Sconto sconto, float totale) {
		
		//this.setMinimoPezziSconto(sconto.getMinimoPezziSconto());
		//this.setMinimoPrezzoSconto(sconto.getMinimoPrezzoSconto());
		this.setPercentualeSconto(sconto.getPercentualeSconto());
		this.setPrezzoSconto(sconto.getPrezzoSconto());
		this.setScadenzaSconto(sconto.getScadenzaSconto());
		super.setProdotto(sconto.getProdotto());
	
		this.totale = totale;
		//this.totaleSconto = totaleSconto;
		setScontoTotale();
	}


	public float getTotale() {
		return totale;
	}
	public void setTotale(float totale) {
		this.totale = totale;
	}

	
	
}
