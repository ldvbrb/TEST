package com.example.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.Fornitore;

public interface FornitoreRepository extends JpaRepository<Fornitore, Integer>{

}
