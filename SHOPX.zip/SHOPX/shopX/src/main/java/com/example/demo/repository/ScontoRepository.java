package com.example.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.model.Sconto;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface ScontoRepository extends JpaRepository<Sconto, Long>, JpaSpecificationExecutor<Sconto> {

}
