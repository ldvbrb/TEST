package com.example.demo.service;

import java.util.List;


import com.example.demo.model.Fornitore;
import com.example.demo.model.Prodotto;

public interface FornitoreService {

	Fornitore getFornitoreById(int id);
	
	Fornitore getFornitoreByName(String nome);
	
	List<String> getNamesFornitoriByXName(String nome);
	
	void deleteFornitoreById(int id);
	
	void saveFornitore(Fornitore fornitore);
	
	void addProdotto(Fornitore fornitore, Prodotto prodotto);	
	
	List<Fornitore> getAllFornitori();

	List<Prodotto> getAllProdotti(int id);
	
	List<Prodotto> getAllProdotti(String nome);
	
	List<String> getAllCategorie(String nome);
	
	List<Fornitore> getFornitoriByName(String nome);

	List<Fornitore> getFornitoriByXName(String nome);

	List<Fornitore> getFornitoriByCategoria(String nome);


}
