package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;


import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.example.demo.model.Fornitore;
import com.example.demo.model.Prodotto;
import com.example.demo.repository.FornitoreRepository;

@Service
public class FornitoreServiceImpl implements FornitoreService{

	@Autowired
	private FornitoreRepository fornitoreRepository;
	
	public FornitoreServiceImpl(){
		
				
	}	
	

	@Override
	public List<Fornitore> getAllFornitori() {
		
		return fornitoreRepository.findAll();	
		
	}
	
	@Override
	public List<Prodotto> getAllProdotti(int id) {	
		
		return getFornitoreById(id).getProdotti();
		
	}
	
	@Override
	public List<Prodotto> getAllProdotti(String nome) {	
		
		return getFornitoreByName(nome).getProdotti();
		
	}


	@Override
	public Fornitore getFornitoreById(int id) {
		
		Optional<Fornitore> optional = fornitoreRepository.findById(id);
		
		Fornitore fornitore = null;
		
		if(optional.isPresent()) {
			fornitore = optional.get();
		} else {			
			//throw new RuntimeException("Fornitore con l'id: " + id + " non è stato trovato");
		}
		
		return fornitore;
		
	}
	
	@Override
	public Fornitore getFornitoreByName(String nome) {
	
			List<Fornitore> fornitori = getAllFornitori();
			
			int id = 0;
			
			Fornitore fornitore = null;			
			
			for(Fornitore fornitoreX : fornitori) {						
				
				id++;
				
				if (fornitoreX.getNome().equals(nome)) {
					
					fornitore = getFornitoreById(id);
					
					break;
					
				}
				
			}
			
			return fornitore;
		
	}
	
	@Override
	public List<Fornitore> getFornitoriByName(String nome) {
	
			List<Fornitore> fornitori = getAllFornitori();
			
			List<Fornitore> subFornitori = new ArrayList<Fornitore>();
			
			int id = 0;
			
			Fornitore fornitore = null;			
			
			for(Fornitore fornitoreX : fornitori) {						
				
				id++;
				
				if (fornitoreX.getNome().equals(nome)) {
					
					fornitore = getFornitoreById(id);
					
					subFornitori.add(fornitore);
										
				}
				
			}
			
			return subFornitori;
		
	}
	
	@Override
	public List<Fornitore> getFornitoriByXName(String nome) {
	
			List<Fornitore> fornitori = getAllFornitori();
			
			List<Fornitore> subFornitori = new ArrayList<Fornitore>();
			
			int id = 0;
			
			Fornitore fornitore = null;			
			
			for(Fornitore fornitoreX : fornitori) {						
				
				id++;
				
				if (fornitoreX.getNome().contains(nome)) {
					
					fornitore = getFornitoreById(id);
					
					subFornitori.add(fornitore);
										
				}
				
			}
			
			return subFornitori;
		
	}
	
	@Override
	public List<String> getNamesFornitoriByXName(String nome) {
	
			List<Fornitore> fornitori = getAllFornitori();
			
			List<String> namesFornitori = new ArrayList<String>();
			
			int id = 0;
			
			String name = null;			
			
			for(Fornitore fornitoreX : fornitori) {						
				
				id++;
				
				if (fornitoreX.getNome().contains(nome)) {
					
					name = getFornitoreById(id).getNome();
					
					namesFornitori.add(name);
					
				}
				
			}
			
			return namesFornitori;
		
	}


	@Override
	public void deleteFornitoreById(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void saveFornitore(Fornitore fornitore) {
		
		fornitoreRepository.save(fornitore);
		
	}


	@Override
	public List<String> getAllCategorie(String nome) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public List<Fornitore> getFornitoriByCategoria(String nome) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void addProdotto(Fornitore fornitore, Prodotto prodotto) {
			
			fornitore.getProdotti().add(prodotto);
			fornitoreRepository.save(fornitore);
			
	}



 


}
