package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Fornitore;
import com.example.demo.model.Prodotto;
import com.example.demo.model.Sconto;

public interface ProdottoService {

	List<Prodotto> getAllProdotti();

	List<Prodotto> getAllProdotti(String categoria);

	public Prodotto getProdottoById(int id);
	
	void saveProdotto(Prodotto prodotto);

	Prodotto getProdottoByCodice(String codice);

	void addScontiProdotto(Prodotto prodotto, List<Sconto> sconti);

}
