package com.example.demo.service;

import java.util.ArrayList;

import java.util.List;


import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.example.demo.model.Fornitore;
import com.example.demo.model.Prodotto;
import com.example.demo.model.Sconto;
import com.example.demo.repository.FornitoreRepository;
import com.example.demo.repository.ProdottoRepository;

@Service
public class ProdottoServiceImpl implements ProdottoService{

	@Autowired
	private ProdottoRepository prodottoRepository;
	
	
	public ProdottoServiceImpl(){
		
				
	}	

	@Override
	public List<Prodotto> getAllProdotti() {	
		
		return prodottoRepository.findAll();
		
	}
	
	@Override
	public List<Prodotto> getAllProdotti(String categoria) {
		
		List<Prodotto> prodottiCategoria = new ArrayList<Prodotto>();
		
		for(Prodotto prodotto : getAllProdotti()) {
		
			if (prodotto.getCategoria().equals(categoria)) {
				
				prodottiCategoria.add(prodotto);
				
			}
				
		}
		
		return prodottiCategoria;
		
	}

	@Override
	public Prodotto getProdottoById(int id) {
		
		Optional<Prodotto> optional = prodottoRepository.findById(id);
		
		Prodotto prodotto = null;
		
		if(optional.isPresent()) {
			prodotto = optional.get();
		} else {			
			//throw new RuntimeException("Fornitore con l'id: " + id + " non è stato trovato");
		}
		
		return prodotto;
	
	
	}
	
	@Override
	public Prodotto getProdottoByCodice(String codice) {
	
			List<Prodotto> prodotti = getAllProdotti();
			
			int id = 0;
			
			Prodotto prodotto = null;			
			
			for(Prodotto p : prodotti) {						
				
				id++;
				
				if (p.getCodice().equals(codice)) {
					
					prodotto = getProdottoById(id);
					
					break;
					
				}
			}
			
			return prodotto;
		
	}
	

	@Override
	public void saveProdotto(Prodotto prodotto) {
		// TODO Auto-generated method stub
		prodottoRepository.save(prodotto);
	}
	

	@Override
	public void addScontiProdotto(Prodotto prodotto,List<Sconto> sconti) {		
		// TODO Auto-generated method stub		
		prodotto.setSconti(sconti);
		prodottoRepository.save(prodotto);
	}

 


}
