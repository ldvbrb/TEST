package com.example.demo.service;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Prodotto;


public interface QueryServiceProdotto extends JpaRepository<Prodotto, Integer> {
	
@Query("SELECT p FROM Prodotto p WHERE p.descrizione like %:val1% and p.pezzi >= :val2")
public List<Prodotto> getProdotti(@Param("val1") String valore1,
								  @Param("val2") Integer valore2);

}
