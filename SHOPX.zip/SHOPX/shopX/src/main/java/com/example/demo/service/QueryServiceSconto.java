package com.example.demo.service;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
import org.springframework.data.repository.query.Param;

import com.example.demo.model.Sconto;



public interface QueryServiceSconto extends JpaRepository<Sconto, Integer> {
	
@Query("SELECT s FROM Sconto s WHERE s.prezzoSconto < :val1")
public List<Sconto> getScontiConPrezzoInfA(@Param("val1") Float valore);

@Query("SELECT s FROM Sconto s")
public List<Sconto> getQuery();

}
